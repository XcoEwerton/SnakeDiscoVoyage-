/* snake.js
   Versão web que replica a lógica do seu jogo pygame.
   Coloque background.png e disco.png na mesma pasta.
*/

const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

const WIDTH = canvas.width;
const HEIGHT = canvas.height;
const box = 20;                // grid size
const baseFPS = 12;            // velocidade base (igual ao seu FPS)
let fpsCurrent = baseFPS;

let playerPos = [Math.floor(WIDTH/2 / box) * box, Math.floor(HEIGHT/2 / box) * box];
let direction = "STOP";
let snakeBody = [[playerPos[0], playerPos[1]]];
let foodPos = randomFood();
let score = 0;
let highscore = loadHighscore();
let gameOver = false;

// Easter eggs (mesmos scores do seu código)
const easterEggs = {
  1000: "XCO: Você está começando a dominar o sistema...",
  5000: "XCO: Isso não é mais sorte. É habilidade alienígena!",
  10000: "XCO: Os terráqueos não estão prontos para você.",
  15000: "XCO: Bem-vindo ao nível dos seres superiores.",
  20000: "XCO: Além disso... você desbloqueou algo? 👀"
};
const shownEggs = new Set();
let currentMessage = "";
let messageTimer = 0;
let msgPos = [0,0];

// Imagens
const imgBg = new Image();
imgBg.src = "background.png";
const imgDisco = new Image();
imgDisco.src = "disco.png";

// ajuste de tamanhos ao desenhar (player maior, food menor)
const playerDrawSize = 60;
const foodDrawSize = 30;

// input teclado
window.addEventListener('keydown', (e) => {
  if (gameOver) {
    if (e.key === "Enter") restartGame();
    if (e.key === "Escape") window.location.reload();
    return;
  }
  if (e.key === "ArrowUp" && direction !== "DOWN") direction = "UP";
  if (e.key === "ArrowDown" && direction !== "UP") direction = "DOWN";
  if (e.key === "ArrowLeft" && direction !== "RIGHT") direction = "LEFT";
  if (e.key === "ArrowRight" && direction !== "LEFT") direction = "RIGHT";
});

// funções utilitárias
function randomFood() {
  const cols = WIDTH / box;
  const rows = HEIGHT / box;
  return [
    Math.floor(Math.random() * cols) * box,
    Math.floor(Math.random() * rows) * box
  ];
}

function saveHighscore(value) {
  try { localStorage.setItem('snake_highscore', String(value)); }
  catch(e){}
}
function loadHighscore() {
  try {
    const v = parseInt(localStorage.getItem('snake_highscore') || "0", 10);
    return isNaN(v) ? 0 : v;
  } catch(e) { return 0; }
}

function triggerMessage(sc) {
  if (easterEggs[sc] && !shownEggs.has(sc)) {
    currentMessage = easterEggs[sc];
    shownEggs.add(sc);
    messageTimer = performance.now();
    // posiciona a mensagem próximo do player (com ajustes)
    const offsets = [[0,-80],[0,80],[-120,0],[120,0]];
    const offset = offsets[Math.floor(Math.random()*offsets.length)];
    msgPos[0] = playerPos[0] + offset[0];
    msgPos[1] = playerPos[1] + offset[1];
    // garantir dentro da tela
    if (msgPos[0] < 10) msgPos[0] = 10;
    if (msgPos[0] > WIDTH - 200) msgPos[0] = WIDTH - 220;
    if (msgPos[1] < 30) msgPos[1] = 30;
    if (msgPos[1] > HEIGHT - 30) msgPos[1] = HEIGHT - 50;
  }
}

// colisão com corpo
function checkSelfCollision(head, body) {
  for (let i = 1; i < body.length; i++) {
    if (head[0] === body[i][0] && head[1] === body[i][1]) return true;
  }
  return false;
}

// reiniciar
function resetGame() {
  playerPos = [Math.floor(WIDTH/2 / box) * box, Math.floor(HEIGHT/2 / box) * box];
  direction = "STOP";
  snakeBody = [[playerPos[0], playerPos[1]]];
  foodPos = randomFood();
  score = 0;
  fpsCurrent = baseFPS;
  currentMessage = "";
  shownEggs.clear();
  gameOver = false;
}
function restartGame() { resetGame(); }

// lógica de movimentação a cada tick (timing controlado por requestAnimationFrame)
let lastTick = 0;
function gameLoop(now) {
  requestAnimationFrame(gameLoop);
  if (!lastTick) lastTick = now;
  const interval = 1000 / Math.max(1, fpsCurrent);
  if (now - lastTick < interval) return; // aguarda o próximo passo
  lastTick = now;

  // background
  if (imgBg.complete) ctx.drawImage(imgBg, 0, 0, WIDTH, HEIGHT);
  else {
    ctx.fillStyle = "#000";
    ctx.fillRect(0,0,WIDTH,HEIGHT);
  }

  if (!gameOver) {
    // turbo escalonado (igual ao seu: base + score//5000)
    fpsCurrent = baseFPS + Math.floor(score / 5000);

    // mover player (em passos de box)
    let head = [playerPos[0], playerPos[1]];
    if (direction === "UP") head[1] -= box;
    if (direction === "DOWN") head[1] += box;
    if (direction === "LEFT") head[0] -= box;
    if (direction === "RIGHT") head[0] += box;

    // teleporte nas bordas (ajustado para grid)
    if (head[0] < 0) head[0] = WIDTH - box;
    if (head[0] >= WIDTH) head[0] = 0;
    if (head[1] < 0) head[1] = HEIGHT - box;
    if (head[1] >= HEIGHT) head[1] = 0;

    // inserir nova cabeça
    snakeBody.unshift(head);
    playerPos = [head[0], head[1]];

    // ver se comeu a comida (tolerância similar ao pygame: distância < 25)
    if (Math.abs(playerPos[0] - foodPos[0]) < 25 && Math.abs(playerPos[1] - foodPos[1]) < 25) {
      score += 100;
      if (score > highscore) { highscore = score; saveHighscore(highscore); }
      foodPos = randomFood();
      triggerMessage(score);
      // não remover cauda -> cresce
    } else {
      // remove cauda normal
      snakeBody.pop();
    }

    // colisão com o próprio corpo -> game over
    if (checkSelfCollision(snakeBody[0], snakeBody)) {
      gameOver = true;
    }

    // desenhar snake (mesma imagem disco para cada segmento)
    for (let seg of snakeBody) {
      if (imgDisco.complete) {
        // centralizar a imagem no lugar do grid (opcional: ajustar para parecer igual)
        ctx.drawImage(imgDisco, seg[0], seg[1], playerDrawSize, playerDrawSize);
      } else {
        ctx.fillStyle = "lime";
        ctx.fillRect(seg[0], seg[1], box, box);
      }
    }

    // desenhar comida (disco menor)
    if (imgDisco.complete) {
      ctx.drawImage(imgDisco, foodPos[0] + (box - foodDrawSize)/2, foodPos[1] + (box - foodDrawSize)/2, foodDrawSize, foodDrawSize);
    } else {
      ctx.fillStyle = "red";
      ctx.fillRect(foodPos[0], foodPos[1], box, box);
    }

    // HUD - score
    ctx.font = "20px Consolas, monospace";
    ctx.fillStyle = "#ffffff";
    ctx.fillText(`🛸 SCORE: ${score}   👑 RECORD: ${highscore}`, 10, 24);

    // desenhar mensagem easter egg
    if (currentMessage) {
      if (performance.now() - messageTimer < 4000) {
        // fundo leve para legibilidade
        ctx.fillStyle = "rgba(0,0,0,0.6)";
        const padding = 8;
        ctx.font = "18px Consolas, monospace";
        const w = ctx.measureText(currentMessage).width + padding * 2;
        const h = 26;
        let x = msgPos[0], y = msgPos[1];
        if (x + w > WIDTH) x = WIDTH - w - 10;
        if (y + h > HEIGHT) y = HEIGHT - h - 10;
        ctx.fillRect(x, y - 18, w, h);
        ctx.fillStyle = "#00ff78";
        ctx.fillText(currentMessage, x + padding, y);
      } else {
        currentMessage = "";
      }
    }

  } else {
    // tela de game over
    ctx.fillStyle = "rgba(0,0,0,0.6)";
    ctx.fillRect(0, 0, WIDTH, HEIGHT);

    ctx.font = "42px Consolas, monospace";
    ctx.fillStyle = "rgb(255,60,60)";
    const title = "💀 GAME OVER 💀";
    ctx.fillText(title, WIDTH/2 - ctx.measureText(title).width/2, HEIGHT/2 - 80);

    ctx.font = "24px Consolas, monospace";
    ctx.fillStyle = "#fff";
    const st = `Score: ${score}  |  Recorde: ${highscore}`;
    ctx.fillText(st, WIDTH/2 - ctx.measureText(st).width/2, HEIGHT/2 - 20);

    ctx.font = "20px Consolas, monospace";
    ctx.fillStyle = "#00ffb2";
    const rtxt = "Pressione ENTER para jogar novamente";
    ctx.fillText(rtxt, WIDTH/2 - ctx.measureText(rtxt).width/2, HEIGHT/2 + 40);

    ctx.fillStyle = "#ccc";
    const etxt = "Pressione ESC para sair";
    ctx.fillText(etxt, WIDTH/2 - ctx.measureText(etxt).width/2, HEIGHT/2 + 80);
  }
}

// iniciar
resetGame();
requestAnimationFrame(gameLoop);
